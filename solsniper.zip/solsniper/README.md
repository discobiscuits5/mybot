# Solana Meme Sniper (Telegram-controlled)

A personal bot that watches every new pump.fun launch, filters out obvious junk,
buys the survivors with a small fixed amount of SOL, and sells automatically on
take-profit, stop-loss, trailing stop, time limit or migration. You control it
from Telegram.

> **Read this first.** Most pump.fun tokens go to zero, and you are competing
> with professional bots running on dedicated hardware. Expect most trades to
> lose; the exits and limits here exist to keep each loss small. Use a fresh
> wallet holding only what you can afford to lose. This is not financial advice.

## How it works

```
PumpPortal websocket ──► new launch
        │
        ▼
Stage 1 filters (instant): name blacklist, dev buy %, starting mcap,
                           serial creator, socials + image in metadata
        │  wait CONFIRM_SECONDS
        ▼
Stage 2 (live curve): real buyers came in (≥ MIN_INFLOW_SOL), not migrated,
                      mcap hasn't already run past MAX_MCAP_SOL
        │
        ▼
Risk gate: not paused, < MAX_OPEN_POSITIONS, < MAX_BUYS_PER_HOUR,
           daily loss limit not hit, wallet keeps MIN_SOL_RESERVE
        │
        ▼
Buy BUY_AMOUNT_SOL ──► monitor every POLL_SECONDS:
   +TAKE_PROFIT_PCT → sell TP_SELL_PCT %, let the rest ride
   −STOP_LOSS_PCT   → sell all
   trailing stop    → sell all if it drops TRAILING_STOP_PCT from peak
   MAX_HOLD_SECONDS → sell all
   migrated         → sell all (SELL_ON_MIGRATION)
```

Your private key never leaves your machine: PumpPortal returns an unsigned
transaction, the bot signs it locally and sends it through your own RPC.
PumpPortal charges 0.5% per trade for this; pump.fun's own fees are on top.

## Setup (about 15 minutes)

1. **Telegram bot.** In Telegram, message `@BotFather` → `/newbot` → copy the token.
2. **Your chat ID.** Message `@userinfobot`; it replies with your numeric ID.
   Then open your new bot and press Start so it's allowed to message you.
3. **Dedicated wallet.** Make a brand-new wallet just for the bot:
   ```bash
   python -c "from solders.keypair import Keypair; k=Keypair(); print('address:', k.pubkey()); print('secret :', k)"
   ```
   Save the secret somewhere safe, then send it a small amount of SOL
   (e.g. 0.3–0.5 SOL). Never use your main wallet's key.
4. **RPC.** Get a free key from Helius, QuickNode or similar. The public
   `api.mainnet-beta.solana.com` is too slow and rate-limited for this.
5. **Install and configure** (Python 3.10+):
   ```bash
   python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
   pip install -r requirements.txt
   cp .env.example .env      # then fill in the four required values
   python -m unittest -v     # offline tests, should all pass
   python main.py
   ```
6. **First start is paused.** The bot messages you on startup. Check `/status`
   and `/config`, then send `/resume` to start trading. Want to watch it decide
   without spending SOL first? `/set dry_run true`, then `/resume`.

## Telegram commands

| Command | What it does |
|---|---|
| `/status` | Running/paused, live vs dry run, wallet balance, today's PnL |
| `/positions` | Open positions with gain, peak, age, estimated PnL |
| `/stats` | Launches seen, how many passed each filter, wins/losses, top rejection reasons |
| `/sell CCAT 50` | Sell 50% of a position (symbol, mint prefix, or `all`) |
| `/panic` | Pause new buys **and** sell everything |
| `/pause` / `/resume` | Stop/start new buys; exits keep running while paused |
| `/config` | Show all tunable settings |
| `/set key value` | Change a setting live, e.g. `/set stop_loss_pct 25` |

`/set` changes last until restart; put them in `.env` to keep them. Buy size is
hard-capped at 0.5 SOL and open positions at 10 in `sniper/config.py`, so a typo
in Telegram can't drain the wallet.

## Tuning tips

- Watch `/stats` for a few hours. If almost nothing passes, the top rejection
  reasons tell you which filter is strictest.
- `CONFIRM_SECONDS=0` makes it a true first-block sniper, but you'll buy far
  more instant rugs. The default (8 s + ≥1 SOL of real buying) trades a slightly
  worse entry for fewer dead launches.
- Failed buys usually mean slippage or priority fee is too low for how busy the
  network is. Raise `priority_fee_sol` first.
- Realized PnL is measured from actual on-chain balance changes. Open-position
  PnL is an estimate at spot price and ignores the slippage you'd pay to sell.

## Running it 24/7

Run it on a small VPS (any $5/month Linux box) inside `tmux` or as a systemd
service so it keeps going when your laptop sleeps. Open positions are saved to
`state.json` and picked up again after a restart.

## Files

```
main.py               start-up: Telegram + websocket + monitor loop
sniper/config.py      settings, .env loading, /set validation and hard caps
sniper/filters.py     rug / quality filters (stage 1 and 2)
sniper/strategy.py    positions and exit rules
sniper/engine.py      buy/sell pipeline, risk limits, state file, reports
sniper/chain.py       Solana RPC, PumpPortal tx building, local signing
sniper/curve.py       pump.fun bonding-curve decoder
sniper/pumpportal.py  new-token websocket with reconnect
sniper/telegram_bot.py  commands, owner-only
tests/test_logic.py   offline tests with a simulated chain
```
