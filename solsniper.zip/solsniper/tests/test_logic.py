"""Offline tests: run with `python -m unittest -v` (no network, no wallet needed)."""
import asyncio
import os
import struct
import tempfile
import unittest

from sniper.config import Settings
from sniper.curve import CurveState, parse_curve
from sniper.engine import Engine
from sniper.filters import NewToken, stage1, stage2
from sniper.strategy import Position, check_exit

SUPPLY_RAW = 1_000_000_000 * 10 ** 6


def make_curve(price_sol: float, vsol: float = 40.0, complete=False) -> CurveState:
    vt = int(vsol / price_sol * 1e6)
    return CurveState(vt, int(vsol * 1e9), vt, int((vsol - 30) * 1e9), SUPPLY_RAW, complete)


def event(mint="MintAAAA1111", creator="Dev1", **kw):
    ev = {"txType": "create", "mint": mint, "traderPublicKey": creator, "name": "Cool Cat",
          "symbol": "CCAT", "uri": "https://ipfs.example/meta", "bondingCurveKey": "Curve" + mint,
          "initialBuy": 30_000_000, "marketCapSol": 30.0, "vSolInBondingCurve": 30.0,
          "pool": "pump"}
    ev.update(kw)
    return ev


GOOD_META = {"image": "https://x/img.png", "twitter": "https://x.com/coolcat"}


def settings(**kw) -> Settings:
    s = Settings(state_file=os.path.join(tempfile.mkdtemp(), "state.json"),
                 confirm_seconds=0, poll_seconds=0.01)
    for k, v in kw.items():
        setattr(s, k, v)
    return s


class CurveTests(unittest.TestCase):
    def test_parse_layout(self):
        data = b"\x00" * 8 + struct.pack("<5Q", 1_073_000_000_000_000, 30_000_000_000,
                                         793_100_000_000_000, 0, SUPPLY_RAW) + b"\x00" + b"\x00" * 32
        c = parse_curve(data)
        self.assertFalse(c.complete)
        self.assertAlmostEqual(c.price_sol, 30 / 1_073_000_000, places=15)
        self.assertAlmostEqual(c.mcap_sol, 27.96, places=1)  # fresh pump.fun token ≈ 28 SOL

    def test_complete_flag(self):
        data = b"\x00" * 8 + struct.pack("<5Q", 1, 1, 0, 0, 1) + b"\x01"
        self.assertTrue(parse_curve(data).complete)


class FilterTests(unittest.TestCase):
    def test_good_token_passes(self):
        self.assertEqual(stage1(NewToken.from_event(event()), GOOD_META, 1, settings()), [])

    def test_rejections(self):
        s = settings()
        bad = NewToken.from_event(event(name="RUG pull", initialBuy=200_000_000))
        r = stage1(bad, {"image": ""}, 3, s)
        joined = " | ".join(r)
        for frag in ("blacklisted", "dev bought 20.0%", "creator launched 3", "no socials", "no image"):
            self.assertIn(frag, joined)

    def test_stage2_inflow(self):
        s = settings(confirm_seconds=5, min_inflow_sol=1.0)
        tok = NewToken.from_event(event())
        self.assertEqual(stage2(tok, make_curve(4e-8, vsol=32.0), s), [])
        self.assertTrue(stage2(tok, make_curve(3e-8, vsol=30.2), s))
        self.assertIn("already migrated", stage2(tok, make_curve(1e-6, 85, True), s))


class ExitTests(unittest.TestCase):
    def pos(self, **kw):
        p = Position("M", "SYM", "C", opened_at=1000.0, sol_spent=0.05, tokens=1000,
                     entry_price=1.0, peak_price=1.0)
        for k, v in kw.items():
            setattr(p, k, v)
        return p

    def test_rules(self):
        s = settings(take_profit_pct=100, tp_sell_pct=50, stop_loss_pct=30,
                     trailing_stop_pct=25, trailing_arm_pct=30, max_hold_seconds=600)
        self.assertIsNone(check_exit(self.pos(), 1.1, False, 1010, s))
        self.assertEqual(check_exit(self.pos(), 0.69, False, 1010, s)[1], 100)
        self.assertEqual(check_exit(self.pos(), 2.0, False, 1010, s)[1], 50)
        # after TP taken, a 25% drop from a 2.5x peak triggers the trailing stop
        r = check_exit(self.pos(tp_done=True, peak_price=2.5), 1.8, False, 1010, s)
        self.assertTrue(r[0].startswith("trailing"))
        # trailing not armed below +30% peak
        self.assertIsNone(check_exit(self.pos(peak_price=1.2), 0.85, False, 1010, s))
        self.assertTrue(check_exit(self.pos(), 1.0, False, 1600, s)[0].startswith("max hold"))
        self.assertTrue(check_exit(self.pos(), 1.0, True, 1010, s)[0].startswith("migrated"))


class ConfigTests(unittest.TestCase):
    def test_caps(self):
        s = settings()
        self.assertIn("0.03", s.set_value("buy_amount_sol", "0.03"))
        with self.assertRaises(ValueError):
            s.set_value("buy_amount_sol", "5")
        with self.assertRaises(ValueError):
            s.set_value("private_key", "x")
        s.set_value("dry_run", "yes")
        self.assertTrue(s.dry_run)


class FakeChain:
    """Simulates RPC + PumpPortal against a price we control."""
    pubkey = "MyWallet"

    def __init__(self):
        self.prices: dict[str, float] = {}
        self.complete: dict[str, bool] = {}
        self.balance = 1.0
        self.held: dict[str, float] = {}
        self.pending: dict[str, tuple[float, float]] = {}
        self.fail_sells = 0
        self.trades = []

    async def get_sol_balance(self):
        return self.balance

    async def get_token_balance(self, mint):
        return self.held.get(mint, 0.0)

    async def fetch_metadata(self, uri):
        return GOOD_META

    async def get_curves(self, addrs):
        out = {}
        for a in addrs:
            mint = a.removeprefix("Curve")
            out[a] = make_curve(self.prices.get(mint, 3e-8), complete=self.complete.get(mint, False))
        return out

    async def trade(self, action, mint, amount, in_sol, slippage, prio, pool="auto"):
        sig = f"sig{len(self.trades)}"
        self.trades.append((action, mint, amount, pool))
        price = self.prices.get(mint, 3e-8)
        if action == "buy":
            tokens = amount * 0.97 / price  # 3% lost to fees/slippage
            self.pending[sig] = (-(amount + 0.001), tokens)
        else:
            if self.fail_sells:
                self.fail_sells -= 1
                self.pending[sig] = None
                return sig
            pct = float(amount.rstrip("%"))
            sold = self.held[mint] * pct / 100
            self.pending[sig] = (sold * price * 0.98, -sold)
        return sig

    async def confirm(self, sig, timeout=45):
        return self.pending.get(sig) is not None

    async def tx_deltas(self, sig, mint):
        sol, tok = self.pending[sig]
        self.held[mint] = self.held.get(mint, 0) + tok
        self.balance += sol
        return sol, tok


class EngineTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.msgs = []

        async def notify(t):
            self.msgs.append(t)
        self.notify = notify

    async def drain(self, eng):
        for _ in range(50):
            if not eng._tasks:
                return
            await asyncio.sleep(0.01)

    async def test_full_cycle_tp_then_trailing(self):
        chain, s = FakeChain(), settings()
        eng = Engine(s, chain, self.notify)
        chain.prices["MintAAAA1111"] = 3e-8
        await eng.on_new_token(event())
        await self.drain(eng)
        self.assertIn("MintAAAA1111", eng.positions)
        pos = eng.positions["MintAAAA1111"]
        self.assertAlmostEqual(pos.sol_spent, 0.051)

        chain.prices["MintAAAA1111"] = 7e-8      # > 2x entry → partial TP
        await eng.tick(); await self.drain(eng)
        self.assertTrue(pos.tp_done)
        self.assertAlmostEqual(pos.tokens, chain.held["MintAAAA1111"])
        self.assertEqual(chain.trades[-1][2], "50%")

        chain.prices["MintAAAA1111"] = 9e-8      # new peak
        await eng.tick()
        chain.prices["MintAAAA1111"] = 6.5e-8    # -28% from peak → trailing stop
        await eng.tick(); await self.drain(eng)
        self.assertNotIn("MintAAAA1111", eng.positions)
        self.assertGreater(eng.closed[-1].realized_pnl(), 0)
        self.assertTrue(any(m.startswith("✅ Closed") for m in self.msgs))
        self.assertTrue(os.path.exists(s.state_file))

    async def test_stop_loss_and_daily_limit_pause(self):
        chain, s = FakeChain(), settings(daily_loss_limit_sol=0.02)
        eng = Engine(s, chain, self.notify)
        await eng.on_new_token(event())
        await self.drain(eng)
        chain.prices["MintAAAA1111"] = 1.5e-8
        await eng.tick(); await self.drain(eng)
        self.assertFalse(eng.positions)
        self.assertTrue(eng.paused)
        self.assertEqual(eng.pause_reason, "daily loss limit")
        await eng.on_new_token(event(mint="MintBBBB2222", creator="Dev2"))
        await self.drain(eng)
        self.assertNotIn("MintBBBB2222", eng.positions)

    async def test_max_positions_no_race(self):
        chain, s = FakeChain(), settings(max_open_positions=1)
        eng = Engine(s, chain, self.notify)
        await eng.on_new_token(event(mint="MintAAAA1111", creator="A"))
        await eng.on_new_token(event(mint="MintBBBB2222", creator="B"))
        await self.drain(eng)
        self.assertEqual(len(eng.positions), 1)
        self.assertEqual(sum(1 for t in chain.trades if t[0] == "buy"), 1)

    async def test_serial_creator_rejected(self):
        chain, s = FakeChain(), settings(max_open_positions=5)
        eng = Engine(s, chain, self.notify)
        await eng.on_new_token(event(mint="Mint1", creator="Spammer"))
        await self.drain(eng)
        await eng.on_new_token(event(mint="Mint2", creator="Spammer"))
        await self.drain(eng)
        self.assertEqual(list(eng.positions), ["Mint1"])

    async def test_sell_failure_retries_later(self):
        chain, s = FakeChain(), settings()
        eng = Engine(s, chain, self.notify)
        await eng.on_new_token(event())
        await self.drain(eng)
        chain.fail_sells = 3                       # one full round of 3 attempts fails
        chain.prices["MintAAAA1111"] = 1.5e-8
        await eng.tick(); await self.drain(eng)
        self.assertIn("MintAAAA1111", eng.positions)
        self.assertTrue(any("Sell failed" in m for m in self.msgs))
        eng.sell_fail["MintAAAA1111"] = (1, 0.0)  # skip the 15s wait
        await eng.tick(); await self.drain(eng)
        self.assertNotIn("MintAAAA1111", eng.positions)

    async def test_low_balance_pauses(self):
        chain, s = FakeChain(), settings()
        chain.balance = 0.06
        eng = Engine(s, chain, self.notify)
        await eng.on_new_token(event())
        await self.drain(eng)
        self.assertFalse(eng.positions)
        self.assertEqual(eng.pause_reason, "low SOL balance")

    async def test_migration_sells_and_state_reload(self):
        chain, s = FakeChain(), settings()
        eng = Engine(s, chain, self.notify)
        await eng.on_new_token(event())
        await self.drain(eng)
        eng2 = Engine(s, chain, self.notify)      # simulate restart
        eng2.load_state()
        self.assertIn("MintAAAA1111", eng2.positions)
        chain.complete["MintAAAA1111"] = True
        await eng2.tick(); await self.drain(eng2)
        self.assertNotIn("MintAAAA1111", eng2.positions)
        self.assertEqual(chain.trades[-1][3], "auto")

    async def test_dry_run_sends_nothing(self):
        chain, s = FakeChain(), settings(dry_run=True)
        eng = Engine(s, chain, self.notify)
        await eng.on_new_token(event())
        await self.drain(eng)
        self.assertIn("MintAAAA1111", eng.positions)
        self.assertEqual(chain.trades, [])
        self.assertIn("[DRY RUN]", self.msgs[0])


if __name__ == "__main__":
    unittest.main()
