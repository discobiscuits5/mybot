"""Entry point: python main.py"""
from __future__ import annotations

import asyncio
import logging
import os

from telegram.ext import Application

from sniper.chain import Chain
from sniper.config import load_settings
from sniper.engine import Engine
from sniper.pumpportal import listen_new_tokens
from sniper.telegram_bot import make_notifier, register_handlers

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s %(levelname)s %(name)s: %(message)s")
logging.getLogger("httpx").setLevel(logging.WARNING)
log = logging.getLogger("sniper")


async def main() -> None:
    s = load_settings()
    chain = Chain(s.rpc_url, s.private_key)
    app = Application.builder().token(s.telegram_token).build()
    engine = Engine(s, chain, make_notifier(app, s.owner_chat_id))

    first_run = not os.path.exists(s.state_file)
    engine.load_state()
    if first_run:
        engine.paused, engine.pause_reason = True, "first start: check /config, then /resume"
    register_handlers(app, engine, chain, s)

    async def stream_status(st: str) -> None:
        engine.stream_status = st

    async with app:
        await app.start()
        await app.updater.start_polling(drop_pending_updates=True)
        bal = await chain.get_sol_balance()
        await engine.notify("🤖 Sniper started\n" + engine.status_text(bal)
                            + f"\nWallet address: {chain.pubkey}\nSend /help for commands.")
        tasks = [
            asyncio.create_task(listen_new_tokens(engine.on_new_token, s.pumpportal_api_key,
                                                  stream_status)),
            asyncio.create_task(engine.monitor_loop()),
        ]
        try:
            await asyncio.gather(*tasks)
        finally:
            for t in tasks:
                t.cancel()
            engine.save_state()
            await app.updater.stop()
            await app.stop()
            await chain.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        log.info("Stopped.")
