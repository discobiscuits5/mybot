"""Decode a pump.fun bonding-curve account. Pure Python, no dependencies.

Layout (Anchor account):
  8  bytes  discriminator
  u64       virtual_token_reserves   (raw, 6 decimals)
  u64       virtual_sol_reserves     (lamports)
  u64       real_token_reserves
  u64       real_sol_reserves
  u64       token_total_supply
  bool      complete                 (True once the token has migrated)
  ...       newer fields (creator, etc.) we don't need
"""
from __future__ import annotations

import base64
import struct
from dataclasses import dataclass

TOKEN_DECIMALS = 6
LAMPORTS_PER_SOL = 1_000_000_000


@dataclass
class CurveState:
    virtual_token_reserves: int
    virtual_sol_reserves: int
    real_token_reserves: int
    real_sol_reserves: int
    token_total_supply: int
    complete: bool

    @property
    def price_sol(self) -> float:
        """Spot price in SOL per whole token."""
        if self.virtual_token_reserves == 0:
            return 0.0
        sol = self.virtual_sol_reserves / LAMPORTS_PER_SOL
        tok = self.virtual_token_reserves / 10 ** TOKEN_DECIMALS
        return sol / tok

    @property
    def mcap_sol(self) -> float:
        return self.price_sol * self.token_total_supply / 10 ** TOKEN_DECIMALS

    @property
    def real_sol(self) -> float:
        return self.real_sol_reserves / LAMPORTS_PER_SOL


def parse_curve(data: bytes) -> CurveState:
    if len(data) < 49:
        raise ValueError(f"bonding curve account too short ({len(data)} bytes)")
    vt, vs, rt, rs, supply = struct.unpack_from("<5Q", data, 8)
    complete = data[48] != 0
    return CurveState(vt, vs, rt, rs, supply, complete)


def parse_curve_b64(b64: str) -> CurveState:
    return parse_curve(base64.b64decode(b64))
