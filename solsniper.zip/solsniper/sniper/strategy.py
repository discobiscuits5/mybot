"""Positions and exit rules. Pure Python, no dependencies."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field

from .config import Settings


@dataclass
class Position:
    mint: str
    symbol: str
    bonding_curve: str
    opened_at: float
    sol_spent: float           # SOL that left the wallet for the buy (incl. fees)
    tokens: float              # whole tokens currently held
    entry_price: float         # SOL per token, = sol_spent / tokens bought
    peak_price: float = 0.0
    last_price: float = 0.0
    tp_done: bool = False
    sol_received: float = 0.0  # SOL realized from sells so far
    buy_sig: str = ""
    sell_sigs: list = field(default_factory=list)
    status: str = "open"       # open | closed
    closed_at: float = 0.0
    exit_reason: str = ""
    dry_run: bool = False

    def gain(self, price: float | None = None) -> float:
        p = self.last_price if price is None else price
        return (p / self.entry_price - 1) if self.entry_price else 0.0

    def est_value(self, price: float | None = None) -> float:
        """Rough value of remaining tokens at spot price (ignores sell slippage)."""
        p = self.last_price if price is None else price
        return self.tokens * p

    def unrealized_pnl(self) -> float:
        return self.sol_received + self.est_value() - self.sol_spent

    def realized_pnl(self) -> float:
        return self.sol_received - self.sol_spent

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Position":
        known = {k: v for k, v in d.items() if k in cls.__dataclass_fields__}
        return cls(**known)


def check_exit(pos: Position, price: float, migrated: bool, now: float,
               s: Settings) -> tuple[str, float] | None:
    """Decide whether to sell. Returns (reason, percent_of_bag) or None.

    Call after updating pos.peak_price with the latest price.
    """
    if migrated:
        return ("migrated to PumpSwap", 100.0) if s.sell_on_migration else None
    if price <= 0 or pos.entry_price <= 0:
        return None

    gain_pct = (price / pos.entry_price - 1) * 100
    peak_gain_pct = (pos.peak_price / pos.entry_price - 1) * 100

    if gain_pct <= -s.stop_loss_pct:
        return (f"stop loss ({gain_pct:+.0f}%)", 100.0)

    if not pos.tp_done and gain_pct >= s.take_profit_pct:
        return (f"take profit ({gain_pct:+.0f}%)", min(100.0, s.tp_sell_pct))

    if (s.trailing_stop_pct > 0 and peak_gain_pct >= s.trailing_arm_pct
            and price <= pos.peak_price * (1 - s.trailing_stop_pct / 100)):
        return (f"trailing stop ({gain_pct:+.0f}%, peak {peak_gain_pct:+.0f}%)", 100.0)

    if s.max_hold_seconds > 0 and now - pos.opened_at >= s.max_hold_seconds:
        return (f"max hold time ({gain_pct:+.0f}%)", 100.0)

    return None
