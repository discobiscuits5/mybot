"""The sniper engine: evaluates launches, buys, watches positions, sells.

No third-party imports here: `chain` and `notify` are injected, so the whole
flow can be tested with fakes.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import time
from collections import Counter, deque
from datetime import datetime, timezone
from typing import Awaitable, Callable

from .config import Settings
from .filters import NewToken, stage1, stage2
from .strategy import Position, check_exit

log = logging.getLogger(__name__)

DUST_SOL = 0.0005          # remaining bag worth less than this = position closed
SELL_RETRY_SECONDS = 15
MAX_CLOSED_KEPT = 200


def utc_day() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


def short(mint: str) -> str:
    return f"{mint[:4]}…{mint[-4:]}"


class Engine:
    def __init__(self, settings: Settings, chain, notify: Callable[[str], Awaitable[None]]):
        self.s = settings
        self.chain = chain
        self.notify = notify

        self.positions: dict[str, Position] = {}
        self.closed: list[Position] = []
        self.paused = False
        self.pause_reason = ""
        self.day = utc_day()
        self.day_realized = 0.0

        self.pending: set[str] = set()            # mints being bought right now
        self.selling: set[str] = set()
        self.sell_fail: dict[str, tuple[int, float]] = {}  # mint -> (fails, retry_at)
        self.seen: dict[str, None] = {}
        self.creators: Counter = Counter()
        self.buy_times: deque = deque()
        self.stats: Counter = Counter()
        self.skip_reasons: Counter = Counter()
        self.stream_status = "starting"

        self._tasks: set[asyncio.Task] = set()
        self._eval_sem = asyncio.Semaphore(25)

    # ------------------------------------------------------------------ state
    def load_state(self) -> None:
        if not os.path.exists(self.s.state_file):
            return
        with open(self.s.state_file) as f:
            d = json.load(f)
        self.positions = {p["mint"]: Position.from_dict(p) for p in d.get("positions", [])}
        self.closed = [Position.from_dict(p) for p in d.get("closed", [])]
        self.paused = d.get("paused", False)
        self.pause_reason = d.get("pause_reason", "")
        if d.get("day") == utc_day():
            self.day, self.day_realized = d["day"], d.get("day_realized", 0.0)
        log.info("Loaded %d open positions from %s", len(self.positions), self.s.state_file)

    def save_state(self) -> None:
        d = {
            "positions": [p.to_dict() for p in self.positions.values()],
            "closed": [p.to_dict() for p in self.closed[-MAX_CLOSED_KEPT:]],
            "paused": self.paused, "pause_reason": self.pause_reason,
            "day": self.day, "day_realized": self.day_realized,
        }
        tmp = self.s.state_file + ".tmp"
        with open(tmp, "w") as f:
            json.dump(d, f, indent=1)
        os.replace(tmp, self.s.state_file)

    def _spawn(self, coro) -> asyncio.Task:
        t = asyncio.create_task(coro)
        self._tasks.add(t)
        t.add_done_callback(self._tasks.discard)
        t.add_done_callback(self._log_crash)
        return t

    @staticmethod
    def _log_crash(t: asyncio.Task) -> None:
        if not t.cancelled() and t.exception():
            log.error("task crashed", exc_info=t.exception())

    # ------------------------------------------------------------- risk gate
    def _roll_day(self) -> None:
        if self.day != utc_day():
            self.day, self.day_realized = utc_day(), 0.0
            if self.paused and self.pause_reason.startswith("daily loss"):
                self.paused, self.pause_reason = False, ""

    def can_buy(self) -> str | None:
        """None if a new buy is allowed, otherwise the reason it isn't."""
        self._roll_day()
        if self.paused:
            return "paused"
        if len(self.positions) + len(self.pending) >= self.s.max_open_positions:
            return "max open positions"
        now = time.time()
        while self.buy_times and now - self.buy_times[0] > 3600:
            self.buy_times.popleft()
        if len(self.buy_times) >= self.s.max_buys_per_hour:
            return "hourly buy limit"
        if -self.day_realized >= self.s.daily_loss_limit_sol:
            return "daily loss limit"
        return None

    # -------------------------------------------------------------- pipeline
    async def on_new_token(self, ev: dict) -> None:
        """Called by the websocket for each launch. Must return fast."""
        mint = ev.get("mint")
        if not mint or mint in self.seen:
            return
        self.seen[mint] = None
        if len(self.seen) > 50_000:
            for k in list(self.seen)[:10_000]:
                del self.seen[k]
        self.stats["seen"] += 1
        creator = ev.get("traderPublicKey", "")
        self.creators[creator] += 1
        if self.can_buy():           # don't even evaluate if we couldn't buy
            self.stats["skipped_capacity"] += 1
            return
        try:
            tok = NewToken.from_event(ev)
        except (KeyError, ValueError, TypeError):
            return
        self._spawn(self._evaluate(tok, self.creators[creator]))

    async def _evaluate(self, tok: NewToken, creator_launches: int) -> None:
        async with self._eval_sem:
            meta = None
            if self.s.require_socials or self.s.require_image:
                meta = await self.chain.fetch_metadata(tok.uri)
            reasons = stage1(tok, meta, creator_launches, self.s)
            if reasons:
                self._skip(reasons)
                return
            self.stats["passed_stage1"] += 1

        if self.s.confirm_seconds > 0:
            await asyncio.sleep(self.s.confirm_seconds)
        curve = (await self.chain.get_curves([tok.bonding_curve])).get(tok.bonding_curve)
        reasons = stage2(tok, curve, self.s)
        if reasons:
            self._skip(reasons)
            return
        self.stats["passed_stage2"] += 1

        # check-and-reserve with no await in between, so parallel evaluations
        # can't both take the last slot
        blocked = self.can_buy()
        if blocked or tok.mint in self.positions or tok.mint in self.pending:
            self.stats["skipped_capacity"] += 1
            return
        self.pending.add(tok.mint)
        try:
            await self._buy(tok, curve)
        finally:
            self.pending.discard(tok.mint)

    def _skip(self, reasons: list[str]) -> None:
        self.stats["rejected"] += 1
        for r in reasons:
            key = re.sub(r"[+-]?\d+(\.\d+)?", "#", r.split("'")[0]).strip()
            self.skip_reasons[key] += 1

    # ------------------------------------------------------------------- buy
    async def _buy(self, tok: NewToken, curve) -> None:
        s = self.s
        amount = s.buy_amount_sol
        if not s.dry_run:
            bal = await self.chain.get_sol_balance()
            if bal - amount - s.priority_fee_sol - 0.003 < s.min_sol_reserve:
                self.paused, self.pause_reason = True, "low SOL balance"
                await self.notify(f"⏸ Paused: wallet has {bal:.4f} SOL, not enough to buy "
                                  f"{amount} SOL and keep the {s.min_sol_reserve} SOL reserve.")
                self.save_state()
                return

        self.buy_times.append(time.time())
        link = f"https://pump.fun/coin/{tok.mint}"
        if s.dry_run:
            price = curve.price_sol
            tokens = amount / price if price else 0
            sol_spent, sig = amount, "DRY-RUN"
        else:
            try:
                sig = await self.chain.trade("buy", tok.mint, amount, True,
                                             s.slippage_pct, s.priority_fee_sol, pool="pump")
            except Exception as e:
                await self.notify(f"❌ Buy request failed for {tok.symbol}: {e}")
                return
            if not await self.chain.confirm(sig):
                self.stats["buy_failed"] += 1
                await self.notify(f"❌ Buy didn't land for {tok.symbol} ({short(tok.mint)})\n"
                                  f"https://solscan.io/tx/{sig}")
                return
            sol_delta, tokens = await self.chain.tx_deltas(sig, tok.mint)
            if tokens <= 0:
                tokens = await self.chain.get_token_balance(tok.mint)
            sol_spent = -sol_delta
            if tokens <= 0 or sol_spent <= 0:
                await self.notify(f"⚠️ Bought {tok.symbol} but couldn't read the fill. "
                                  f"Check manually: https://solscan.io/tx/{sig}")
                return

        entry = sol_spent / tokens
        pos = Position(mint=tok.mint, symbol=tok.symbol, bonding_curve=tok.bonding_curve,
                       opened_at=time.time(), sol_spent=sol_spent, tokens=tokens,
                       entry_price=entry, peak_price=entry, last_price=entry,
                       buy_sig=sig, dry_run=s.dry_run)
        self.positions[tok.mint] = pos
        self.stats["bought"] += 1
        self.save_state()
        tag = " [DRY RUN]" if s.dry_run else ""
        await self.notify(
            f"🟢 Bought {tok.symbol}{tag}\n{tok.name}\n"
            f"Spent {sol_spent:.4f} SOL · dev buy {tok.dev_buy_pct:.1f}% · "
            f"mcap {curve.mcap_sol:.1f} SOL\n{link}"
            + ("" if s.dry_run else f"\nhttps://solscan.io/tx/{sig}"))

    # --------------------------------------------------------------- monitor
    async def monitor_loop(self) -> None:
        while True:
            try:
                await self.tick()
            except asyncio.CancelledError:
                raise
            except Exception as e:
                log.warning("monitor tick failed: %s", e)
            await asyncio.sleep(self.s.poll_seconds)

    async def tick(self) -> None:
        if not self.positions:
            return
        open_pos = list(self.positions.values())
        curves = await self.chain.get_curves([p.bonding_curve for p in open_pos])
        now = time.time()
        for pos in open_pos:
            if pos.mint in self.selling:
                continue
            fails, retry_at = self.sell_fail.get(pos.mint, (0, 0.0))
            if now < retry_at:
                continue
            curve = curves.get(pos.bonding_curve)
            if curve is None:
                continue
            migrated = curve.complete
            if not migrated:
                pos.last_price = curve.price_sol
                pos.peak_price = max(pos.peak_price, pos.last_price)
            decision = check_exit(pos, pos.last_price, migrated, now, self.s)
            if decision:
                reason, pct = decision
                self.selling.add(pos.mint)
                self._spawn(self._sell(pos, pct, reason))

    # ------------------------------------------------------------------ sell
    async def _sell(self, pos: Position, pct: float, reason: str) -> bool:
        self.selling.add(pos.mint)
        try:
            return await self._sell_inner(pos, pct, reason)
        finally:
            self.selling.discard(pos.mint)

    async def _sell_inner(self, pos: Position, pct: float, reason: str) -> bool:
        s = self.s
        if pos.dry_run:
            sold = pos.tokens * pct / 100
            pos.sol_received += sold * pos.last_price * 0.98  # rough fee/slippage haircut
            pos.tokens -= sold
            sig = "DRY-RUN"
        else:
            sig, ok = "", False
            for attempt in range(3):
                slip = min(99.0, s.slippage_pct + 15 * attempt)
                try:
                    sig = await self.chain.trade("sell", pos.mint, f"{pct:g}%", False,
                                                 slip, s.priority_fee_sol * (1 + attempt), pool="auto")
                    ok = await self.chain.confirm(sig)
                except Exception as e:
                    log.warning("sell attempt %d for %s failed: %s", attempt + 1, pos.mint, e)
                    ok = False
                if ok:
                    break
            if not ok:
                fails = self.sell_fail.get(pos.mint, (0, 0.0))[0] + 1
                self.sell_fail[pos.mint] = (fails, time.time() + SELL_RETRY_SECONDS)
                if fails == 1 or fails % 5 == 0:
                    await self.notify(f"⚠️ Sell failed for {pos.symbol} ({reason}), attempt "
                                      f"round {fails}. Retrying every {SELL_RETRY_SECONDS}s.\n"
                                      f"https://pump.fun/coin/{pos.mint}")
                return False
            self.sell_fail.pop(pos.mint, None)
            sol_delta, tok_delta = await self.chain.tx_deltas(sig, pos.mint)
            pos.sol_received += max(sol_delta, 0.0)
            pos.tokens = (pos.tokens + tok_delta) if tok_delta < 0 else \
                await self.chain.get_token_balance(pos.mint)
        pos.sell_sigs.append(sig)

        closed = pct >= 100 or pos.tokens * pos.last_price < DUST_SOL
        if not closed:
            pos.tp_done = True
            self.save_state()
            await self.notify(
                f"🟡 Sold {pct:g}% of {pos.symbol}: {reason}\n"
                f"Realized so far {pos.sol_received:.4f} / spent {pos.sol_spent:.4f} SOL")
            return True

        pos.status, pos.closed_at, pos.exit_reason = "closed", time.time(), reason
        self.positions.pop(pos.mint, None)
        self.closed.append(pos)
        pnl = pos.realized_pnl()
        self._roll_day()
        if not pos.dry_run:
            self.day_realized += pnl
        self.stats["wins" if pnl > 0 else "losses"] += 1
        emoji = "✅" if pnl > 0 else "🔴"
        await self.notify(
            f"{emoji} Closed {pos.symbol}: {reason}\n"
            f"PnL {pnl:+.4f} SOL ({pnl / pos.sol_spent * 100:+.0f}%)"
            + ("" if sig == "DRY-RUN" else f"\nhttps://solscan.io/tx/{sig}"))
        if -self.day_realized >= s.daily_loss_limit_sol and not self.paused:
            self.paused, self.pause_reason = True, "daily loss limit"
            await self.notify(f"⏸ Paused: daily loss limit hit ({self.day_realized:+.4f} SOL). "
                              f"Resumes automatically tomorrow (UTC) or with /resume.")
        self.save_state()
        return True

    # ------------------------------------------------------ manual controls
    def find(self, query: str) -> list[Position]:
        q = query.strip().lower()
        if q == "all":
            return list(self.positions.values())
        return [p for p in self.positions.values()
                if p.mint.lower().startswith(q) or p.mint.lower() == q or p.symbol.lower() == q]

    async def sell_manual(self, query: str, pct: float = 100.0) -> str:
        targets = self.find(query)
        if not targets:
            return "No matching open position."
        started = []
        for p in targets:
            if p.mint in self.selling:
                continue
            self.selling.add(p.mint)
            self._spawn(self._sell(p, pct, "manual sell"))
            started.append(p.symbol)
        return f"Selling {pct:g}% of: {', '.join(started)}" if started else "Already selling."

    async def panic(self) -> str:
        self.paused, self.pause_reason = True, "panic"
        self.save_state()
        msg = await self.sell_manual("all") if self.positions else "No open positions."
        return "⏸ Paused. " + msg

    # ------------------------------------------------------------- reports
    def status_text(self, balance: float | None) -> str:
        self._roll_day()
        state = f"⏸ PAUSED ({self.pause_reason})" if self.paused else "▶️ RUNNING"
        mode = "DRY RUN" if self.s.dry_run else "LIVE"
        bal = f"{balance:.4f} SOL" if balance is not None else "unavailable"
        unreal = sum(p.unrealized_pnl() for p in self.positions.values())
        return (f"{state} · {mode}\nStream: {self.stream_status}\nWallet: {bal}\n"
                f"Open: {len(self.positions)}/{self.s.max_open_positions} "
                f"(unrealized {unreal:+.4f} SOL)\n"
                f"Today realized: {self.day_realized:+.4f} SOL "
                f"(limit -{self.s.daily_loss_limit_sol})\n"
                f"Buy size: {self.s.buy_amount_sol} SOL")

    def positions_text(self) -> str:
        if not self.positions:
            return "No open positions."
        now = time.time()
        out = []
        for p in self.positions.values():
            age = int(now - p.opened_at)
            out.append(f"{p.symbol} ({short(p.mint)}){' [DRY]' if p.dry_run else ''}\n"
                       f"  {p.gain() * 100:+.0f}% · peak {(p.peak_price / p.entry_price - 1) * 100:+.0f}%"
                       f" · {age // 60}m{age % 60:02d}s · est PnL {p.unrealized_pnl():+.4f} SOL"
                       f"{' · TP taken' if p.tp_done else ''}\n  https://pump.fun/coin/{p.mint}")
        return "\n\n".join(out)

    def stats_text(self) -> str:
        st = self.stats
        live = [p for p in self.closed if not p.dry_run]
        total = sum(p.realized_pnl() for p in live)
        top = "\n".join(f"  {n}× {r}" for r, n in self.skip_reasons.most_common(6)) or "  none yet"
        return (f"Launches seen: {st['seen']}\nPassed instant filters: {st['passed_stage1']}\n"
                f"Passed confirm check: {st['passed_stage2']}\nBought: {st['bought']} "
                f"(failed buys {st['buy_failed']})\nWins/losses: {st['wins']}/{st['losses']}\n"
                f"Live realized PnL (last {len(live)} closed): {total:+.4f} SOL\n"
                f"Top rejection reasons:\n{top}")
