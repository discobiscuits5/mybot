"""Rug / quality filters. Pure functions so they're easy to test and tweak.

Stage 1 runs instantly on the creation event (+ token metadata).
Stage 2 runs after `confirm_seconds`, against the live bonding curve, to make
sure real buyers showed up and the dev didn't dump.

These filters cut down obvious junk. They do NOT make a token safe.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .config import Settings
from .curve import CurveState

TOTAL_SUPPLY_TOKENS = 1_000_000_000  # pump.fun tokens are 1B supply


@dataclass
class NewToken:
    mint: str
    creator: str
    name: str
    symbol: str
    uri: str
    bonding_curve: str
    initial_buy_tokens: float
    mcap_sol: float
    v_sol: float
    pool: str = "pump"
    raw: dict = field(default_factory=dict, repr=False)

    @classmethod
    def from_event(cls, ev: dict) -> "NewToken":
        return cls(
            mint=ev["mint"],
            creator=ev.get("traderPublicKey", ""),
            name=str(ev.get("name", "")),
            symbol=str(ev.get("symbol", "")),
            uri=str(ev.get("uri", "")),
            bonding_curve=ev.get("bondingCurveKey", ""),
            initial_buy_tokens=float(ev.get("initialBuy", 0) or 0),
            mcap_sol=float(ev.get("marketCapSol", 0) or 0),
            v_sol=float(ev.get("vSolInBondingCurve", 0) or 0),
            pool=str(ev.get("pool", "pump") or "pump"),
            raw=ev,
        )

    @property
    def dev_buy_pct(self) -> float:
        return self.initial_buy_tokens / TOTAL_SUPPLY_TOKENS * 100


def stage1(tok: NewToken, meta: dict | None, creator_launches: int, s: Settings) -> list[str]:
    """Return a list of rejection reasons (empty list = pass)."""
    reasons: list[str] = []
    text = f"{tok.name} {tok.symbol}".lower()
    hit = next((w for w in s.blacklist if w in text), None)
    if hit:
        reasons.append(f"blacklisted word '{hit}'")
    if not tok.name.strip() or not tok.symbol.strip():
        reasons.append("empty name/symbol")
    if not tok.bonding_curve:
        reasons.append("no bonding curve in event")
    if tok.pool not in ("pump", ""):
        reasons.append(f"not a pump.fun curve launch (pool={tok.pool})")
    if tok.dev_buy_pct > s.max_dev_buy_pct:
        reasons.append(f"dev bought {tok.dev_buy_pct:.1f}% of supply")
    if tok.mcap_sol < s.min_mcap_sol or tok.mcap_sol > s.max_mcap_sol:
        reasons.append(f"mcap {tok.mcap_sol:.1f} SOL out of range")
    if creator_launches > s.max_creator_launches:
        reasons.append(f"creator launched {creator_launches} tokens this session")

    if s.require_socials or s.require_image:
        if meta is None:
            reasons.append("metadata unavailable")
        else:
            if s.require_socials and not any(
                str(meta.get(k, "")).strip() for k in ("twitter", "telegram", "website")
            ):
                reasons.append("no socials")
            if s.require_image and not str(meta.get("image", "")).strip():
                reasons.append("no image")
    return reasons


def stage2(tok: NewToken, curve: CurveState | None, s: Settings) -> list[str]:
    """Post-confirmation check against the live curve."""
    if curve is None:
        return ["bonding curve not readable"]
    reasons: list[str] = []
    if curve.complete:
        reasons.append("already migrated")
    inflow = curve.virtual_sol_reserves / 1e9 - tok.v_sol
    if s.confirm_seconds > 0 and inflow < s.min_inflow_sol:
        reasons.append(f"net inflow {inflow:+.2f} SOL < {s.min_inflow_sol}")
    if curve.mcap_sol > s.max_mcap_sol:
        reasons.append(f"mcap ran to {curve.mcap_sol:.1f} SOL")
    return reasons
