"""Settings loaded from .env, with a few values editable live from Telegram (/set)."""
from __future__ import annotations

import os
from dataclasses import dataclass, field, fields

# Hard ceilings that /set can never exceed. Edit here (not from Telegram) if you
# really want to raise them.
HARD_MAX_BUY_SOL = 0.5
HARD_MAX_OPEN_POSITIONS = 10


def _env(name: str, default: str | None = None) -> str | None:
    v = os.getenv(name)
    return v if v not in (None, "") else default


def _bool(v: str | bool) -> bool:
    if isinstance(v, bool):
        return v
    return str(v).strip().lower() in ("1", "true", "yes", "on", "y")


@dataclass
class Settings:
    # --- secrets / connections (not editable from Telegram) ---
    telegram_token: str = ""
    owner_chat_id: int = 0
    private_key: str = ""            # base58 secret key of a DEDICATED hot wallet
    rpc_url: str = "https://api.mainnet-beta.solana.com"
    pumpportal_api_key: str = ""     # optional; only free new-token stream is used
    state_file: str = "state.json"

    # --- trading (editable) ---
    dry_run: bool = False            # True = log decisions, never send transactions
    buy_amount_sol: float = 0.05
    slippage_pct: float = 25.0
    priority_fee_sol: float = 0.0005
    max_open_positions: int = 3
    max_buys_per_hour: int = 10
    min_sol_reserve: float = 0.05    # always keep this much SOL for fees
    daily_loss_limit_sol: float = 0.3  # auto-pause after this much realized loss (UTC day)

    # --- exits (editable) ---
    take_profit_pct: float = 100.0   # +100% = 2x
    tp_sell_pct: float = 50.0        # sell this % of the bag at take profit
    stop_loss_pct: float = 30.0
    trailing_stop_pct: float = 25.0  # from peak, once trailing is armed
    trailing_arm_pct: float = 30.0   # arm trailing stop after this gain
    max_hold_seconds: int = 600
    sell_on_migration: bool = True
    poll_seconds: float = 1.5

    # --- rug filters (editable) ---
    confirm_seconds: float = 8.0     # wait & re-check the curve before buying (0 = instant)
    min_inflow_sol: float = 1.0      # net SOL that must flow in during confirm window
    max_dev_buy_pct: float = 8.0     # dev's initial buy as % of supply
    min_mcap_sol: float = 0.0
    max_mcap_sol: float = 60.0
    require_socials: bool = True     # twitter / telegram / website in metadata
    require_image: bool = True
    max_creator_launches: int = 1    # creator seen launching more than this = skip
    name_blacklist: str = "test,rug,scam,honeypot,airdrop"

    # which fields /set may change
    EDITABLE: tuple = field(default=(
        "dry_run", "buy_amount_sol", "slippage_pct", "priority_fee_sol",
        "max_open_positions", "max_buys_per_hour", "min_sol_reserve",
        "daily_loss_limit_sol", "take_profit_pct", "tp_sell_pct", "stop_loss_pct",
        "trailing_stop_pct", "trailing_arm_pct", "max_hold_seconds",
        "sell_on_migration", "confirm_seconds", "min_inflow_sol", "max_dev_buy_pct",
        "min_mcap_sol", "max_mcap_sol", "require_socials", "require_image",
        "max_creator_launches", "name_blacklist",
    ), repr=False)

    @property
    def blacklist(self) -> list[str]:
        return [w.strip().lower() for w in self.name_blacklist.split(",") if w.strip()]

    def set_value(self, key: str, raw: str) -> str:
        """Parse and validate a /set command. Returns a confirmation or raises ValueError."""
        key = key.strip().lower()
        if key not in self.EDITABLE:
            raise ValueError(f"'{key}' can't be changed from Telegram.")
        current = getattr(self, key)
        if isinstance(current, bool):
            value = _bool(raw)
        elif isinstance(current, int):
            value = int(float(raw))
        elif isinstance(current, float):
            value = float(raw)
        else:
            value = raw
        if isinstance(value, (int, float)) and not isinstance(value, bool) and value < 0:
            raise ValueError("Value can't be negative.")
        if key == "buy_amount_sol" and value > HARD_MAX_BUY_SOL:
            raise ValueError(f"Max buy is capped at {HARD_MAX_BUY_SOL} SOL (see config.py).")
        if key == "max_open_positions" and value > HARD_MAX_OPEN_POSITIONS:
            raise ValueError(f"Max open positions is capped at {HARD_MAX_OPEN_POSITIONS}.")
        if key in ("tp_sell_pct",) and not 0 < value <= 100:
            raise ValueError("tp_sell_pct must be between 1 and 100.")
        if key == "stop_loss_pct" and not 0 < value < 100:
            raise ValueError("stop_loss_pct must be between 1 and 99.")
        setattr(self, key, value)
        return f"{key} = {value}"

    def describe(self) -> str:
        lines = []
        for f in fields(self):
            if f.name in self.EDITABLE:
                lines.append(f"{f.name} = {getattr(self, f.name)}")
        return "\n".join(lines)


def load_settings() -> Settings:
    try:
        from dotenv import load_dotenv
        load_dotenv()
    except ImportError:
        pass

    s = Settings()
    s.telegram_token = _env("TELEGRAM_BOT_TOKEN", "") or ""
    s.owner_chat_id = int(_env("TELEGRAM_OWNER_CHAT_ID", "0") or 0)
    s.private_key = _env("WALLET_PRIVATE_KEY", "") or ""
    s.rpc_url = _env("SOLANA_RPC_URL", s.rpc_url) or s.rpc_url
    s.pumpportal_api_key = _env("PUMPPORTAL_API_KEY", "") or ""
    s.state_file = _env("STATE_FILE", s.state_file) or s.state_file

    # Any editable setting can also be given in .env, upper-cased.
    for key in s.EDITABLE:
        raw = _env(key.upper())
        if raw is not None:
            s.set_value(key, raw)

    missing = [n for n, v in (("TELEGRAM_BOT_TOKEN", s.telegram_token),
                              ("TELEGRAM_OWNER_CHAT_ID", s.owner_chat_id),
                              ("WALLET_PRIVATE_KEY", s.private_key)) if not v]
    if missing:
        raise SystemExit(f"Missing required .env values: {', '.join(missing)}")
    return s
