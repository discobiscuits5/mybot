"""Telegram control panel. Only your chat (TELEGRAM_OWNER_CHAT_ID) can use it."""
from __future__ import annotations

import logging

from telegram import LinkPreviewOptions, Update
from telegram.ext import Application, CommandHandler, ContextTypes, filters

from .config import Settings

log = logging.getLogger(__name__)

HELP = """Solana meme sniper 🎯

/status – running/paused, wallet, today's PnL
/positions – open positions
/stats – launches seen, filter results, wins/losses
/sell <symbol|mint|all> [percent] – manual sell (default 100%)
/panic – pause AND sell everything
/pause, /resume – stop/start new buys (exits keep running)
/config – show settings
/set <key> <value> – change a setting, e.g. /set buy_amount_sol 0.03
/help – this message"""

NO_PREVIEW = LinkPreviewOptions(is_disabled=True)


def make_notifier(app: Application, chat_id: int):
    async def notify(text: str) -> None:
        try:
            await app.bot.send_message(chat_id=chat_id, text=text[:4000],
                                       link_preview_options=NO_PREVIEW)
        except Exception as e:  # never let Telegram hiccups break trading
            log.warning("telegram notify failed: %s", e)
    return notify


def register_handlers(app: Application, engine, chain, s: Settings) -> None:
    owner = filters.Chat(chat_id=s.owner_chat_id)

    async def reply(update: Update, text: str) -> None:
        await update.effective_message.reply_text(text[:4000], link_preview_options=NO_PREVIEW)

    async def help_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        await reply(update, HELP)

    async def status(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        try:
            bal = await chain.get_sol_balance()
        except Exception:
            bal = None
        await reply(update, engine.status_text(bal) + f"\nWallet address: {chain.pubkey}")

    async def positions(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        await reply(update, engine.positions_text())

    async def stats(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        await reply(update, engine.stats_text())

    async def pause(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        engine.paused, engine.pause_reason = True, "manual"
        engine.save_state()
        await reply(update, "⏸ Paused new buys. Open positions are still managed.")

    async def resume(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        engine.paused, engine.pause_reason = False, ""
        engine.save_state()
        mode = "DRY RUN" if s.dry_run else "LIVE"
        await reply(update, f"▶️ Resumed ({mode}, {s.buy_amount_sol} SOL per buy).")

    async def sell(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await reply(update, "Usage: /sell <symbol|mint|all> [percent]")
            return
        pct = 100.0
        if len(ctx.args) > 1:
            try:
                pct = float(ctx.args[1].rstrip("%"))
                assert 0 < pct <= 100
            except (ValueError, AssertionError):
                await reply(update, "Percent must be between 1 and 100.")
                return
        await reply(update, await engine.sell_manual(ctx.args[0], pct))

    async def panic(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        await reply(update, await engine.panic())

    async def config(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        await reply(update, s.describe())

    async def set_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if len(ctx.args) < 2:
            await reply(update, "Usage: /set <key> <value>   (see /config for keys)")
            return
        try:
            msg = s.set_value(ctx.args[0], " ".join(ctx.args[1:]))
        except ValueError as e:
            await reply(update, f"❌ {e}")
            return
        log.info("setting changed via Telegram: %s", msg)
        await reply(update, f"✅ {msg}  (until restart; put it in .env to keep it)")

    for name, fn in {
        "start": help_cmd, "help": help_cmd, "status": status, "positions": positions,
        "stats": stats, "pause": pause, "resume": resume, "sell": sell, "panic": panic,
        "config": config, "set": set_cmd,
    }.items():
        app.add_handler(CommandHandler(name, fn, filters=owner))
