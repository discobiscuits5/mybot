"""Solana RPC + PumpPortal transaction building. Your private key never leaves
this process: PumpPortal returns an unsigned transaction, we sign it locally
and send it through YOUR RPC.
"""
from __future__ import annotations

import asyncio
import base64
import logging

import httpx
from solders.keypair import Keypair
from solders.transaction import VersionedTransaction

from .curve import CurveState, parse_curve_b64

log = logging.getLogger(__name__)

TRADE_LOCAL_URL = "https://pumpportal.fun/api/trade-local"


class RpcError(RuntimeError):
    pass


class Chain:
    def __init__(self, rpc_url: str, private_key: str):
        self.rpc_url = rpc_url
        self.keypair = Keypair.from_base58_string(private_key.strip())
        self.pubkey = str(self.keypair.pubkey())
        self.http = httpx.AsyncClient(timeout=httpx.Timeout(10.0), follow_redirects=True)
        self._id = 0

    async def close(self) -> None:
        await self.http.aclose()

    # ---------- low-level RPC ----------
    async def rpc(self, method: str, params: list):
        self._id += 1
        r = await self.http.post(self.rpc_url, json={
            "jsonrpc": "2.0", "id": self._id, "method": method, "params": params})
        r.raise_for_status()
        body = r.json()
        if "error" in body:
            raise RpcError(f"{method}: {body['error']}")
        return body.get("result")

    # ---------- reads ----------
    async def get_sol_balance(self) -> float:
        res = await self.rpc("getBalance", [self.pubkey, {"commitment": "confirmed"}])
        return res["value"] / 1e9

    async def get_token_balance(self, mint: str) -> float:
        res = await self.rpc("getTokenAccountsByOwner", [
            self.pubkey, {"mint": mint},
            {"encoding": "jsonParsed", "commitment": "confirmed"}])
        total = 0.0
        for acc in res.get("value", []):
            amt = acc["account"]["data"]["parsed"]["info"]["tokenAmount"]
            total += float(amt.get("uiAmountString") or amt.get("uiAmount") or 0)
        return total

    async def get_curves(self, addresses: list[str]) -> dict[str, CurveState | None]:
        out: dict[str, CurveState | None] = {}
        for i in range(0, len(addresses), 100):
            chunk = addresses[i:i + 100]
            res = await self.rpc("getMultipleAccounts", [
                chunk, {"encoding": "base64", "commitment": "confirmed"}])
            for addr, acc in zip(chunk, res["value"]):
                try:
                    out[addr] = parse_curve_b64(acc["data"][0]) if acc else None
                except Exception as e:  # malformed / unexpected layout
                    log.warning("curve parse failed for %s: %s", addr, e)
                    out[addr] = None
        return out

    async def fetch_metadata(self, uri: str) -> dict | None:
        if not uri:
            return None
        try:
            r = await self.http.get(uri, timeout=4.0)
            if r.status_code == 200:
                data = r.json()
                return data if isinstance(data, dict) else None
        except Exception as e:
            log.debug("metadata fetch failed %s: %s", uri, e)
        return None

    # ---------- trading ----------
    async def trade(self, action: str, mint: str, amount, denominated_in_sol: bool,
                    slippage: float, priority_fee: float, pool: str = "auto") -> str:
        """Build via PumpPortal, sign locally, send via our RPC. Returns signature."""
        r = await self.http.post(TRADE_LOCAL_URL, data={
            "publicKey": self.pubkey,
            "action": action,
            "mint": mint,
            "amount": str(amount),
            "denominatedInSol": "true" if denominated_in_sol else "false",
            "slippage": str(slippage),
            "priorityFee": str(priority_fee),
            "pool": pool,
        })
        if r.status_code != 200:
            raise RpcError(f"PumpPortal {r.status_code}: {r.text[:200]}")
        unsigned = VersionedTransaction.from_bytes(r.content)
        signed = VersionedTransaction(unsigned.message, [self.keypair])
        b64 = base64.b64encode(bytes(signed)).decode()
        return await self.rpc("sendTransaction", [b64, {
            "encoding": "base64", "skipPreflight": True, "maxRetries": 3}])

    async def confirm(self, sig: str, timeout: float = 45.0) -> bool:
        """True if landed without error, False if it failed or never landed."""
        loop = asyncio.get_running_loop()
        deadline = loop.time() + timeout
        while loop.time() < deadline:
            res = await self.rpc("getSignatureStatuses", [[sig], {"searchTransactionHistory": False}])
            st = res["value"][0]
            if st:
                if st.get("err"):
                    log.info("tx %s failed: %s", sig, st["err"])
                    return False
                if st.get("confirmationStatus") in ("confirmed", "finalized"):
                    return True
            await asyncio.sleep(1.0)
        return False

    async def tx_deltas(self, sig: str, mint: str) -> tuple[float, float]:
        """(SOL change, token change) for our wallet in a confirmed tx."""
        for _ in range(8):
            tx = await self.rpc("getTransaction", [sig, {
                "encoding": "json", "maxSupportedTransactionVersion": 0,
                "commitment": "confirmed"}])
            if tx and tx.get("meta"):
                meta = tx["meta"]
                sol = (meta["postBalances"][0] - meta["preBalances"][0]) / 1e9

                def tok(entries):
                    return sum(float(e["uiTokenAmount"].get("uiAmountString") or 0)
                               for e in entries or []
                               if e.get("mint") == mint and e.get("owner") == self.pubkey)

                return sol, tok(meta.get("postTokenBalances")) - tok(meta.get("preTokenBalances"))
            await asyncio.sleep(1.0)
        raise RpcError(f"transaction {sig} not found")
