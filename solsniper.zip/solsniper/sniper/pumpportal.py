"""PumpPortal websocket: streams new pump.fun token launches (free stream).

Uses ONE connection and reconnects with backoff, as PumpPortal asks.
"""
from __future__ import annotations

import asyncio
import json
import logging
from typing import Awaitable, Callable

import websockets

log = logging.getLogger(__name__)

WS_URL = "wss://pumpportal.fun/api/data"


async def listen_new_tokens(on_token: Callable[[dict], Awaitable[None]],
                            api_key: str = "",
                            on_status: Callable[[str], Awaitable[None]] | None = None) -> None:
    url = f"{WS_URL}?api-key={api_key}" if api_key else WS_URL
    backoff = 2
    while True:
        try:
            async with websockets.connect(url, ping_interval=20, ping_timeout=20,
                                          max_size=2 ** 20) as ws:
                await ws.send(json.dumps({"method": "subscribeNewToken"}))
                log.info("Connected to PumpPortal, listening for new tokens")
                if on_status:
                    await on_status("connected")
                backoff = 2
                async for msg in ws:
                    try:
                        ev = json.loads(msg)
                    except ValueError:
                        continue
                    # first message is a subscription ack; launches have txType=create
                    if isinstance(ev, dict) and ev.get("txType") == "create" and ev.get("mint"):
                        await on_token(ev)  # must return quickly; engine spawns its own task
        except asyncio.CancelledError:
            raise
        except Exception as e:
            log.warning("PumpPortal stream dropped: %s (retry in %ss)", e, backoff)
            if on_status:
                await on_status(f"disconnected: {e}")
            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, 60)
